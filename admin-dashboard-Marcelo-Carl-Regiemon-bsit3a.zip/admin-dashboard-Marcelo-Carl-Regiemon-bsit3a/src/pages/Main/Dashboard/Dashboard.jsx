import React, { useState } from 'react';
import './Dashboard.css';

const Dashboard = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const movies = ['Inception', 'Interstellar', 'The Dark Knight', 'Titanic', 'Avatar']; // Example movies

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    return (
        <div className="dashboard">
            <h1>Dashboard</h1>
            <p>Welcome to your dashboard!</p>

            <div className="search-bar">
                <input 
                    type="text" 
                    placeholder="Search for movies..." 
                    value={searchTerm} 
                    onChange={handleSearch} 
                />
            </div>

            <h2>Movies</h2>
            <ul className="movies-list">
                {movies.filter(movie => movie.toLowerCase().includes(searchTerm.toLowerCase())).map((movie, index) => (
                    <li key={index}>{movie}</li>
                ))}
            </ul>
        </div>
    );
};

const Sidebar = () => {
    return (
        <div className="sidebar">
            <h2>Menu</h2>
            <a href="#dashboard" className="active">Dashboard</a>
            <a href="#movies">Movies</a>
            <a href="#logout">Logout</a>
        </div>
    );
};

export default Dashboard;