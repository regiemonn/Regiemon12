import React, { useState } from 'react';

const Movies = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const movies = [
        'Inception',
        'Interstellar',
        'The Dark Knight',
        'Titanic',
        'Avatar'
    ]; // Example movies list

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    return (
        <div>
            <div className="search-bar">
                <input 
                    type="text" 
                    placeholder="Search for movies..." 
                    value={searchTerm} 
                    onChange={handleSearch} 
                />
            </div>

            <h2>Movies</h2>
            <ul className="movies-list">
                {movies
                    .filter(movie => movie.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map((movie, index) => (
                        <li key={index}>{movie}</li>
                    ))}
            </ul>
        </div>
    );
};

export default Movies;